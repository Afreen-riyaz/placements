package com.bms.placement.student;

import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

@Service
@Transactional
public class StudentService {
	
	@Autowired
	private StudentRepository repo;	
	//Insert the record into the database
	public void insertRecord(Student stu)
	{
		repo.save(stu);
	}
	
	//Get all the records from the table
	public List<Student> listAllRecords()
	{
		return repo.findAll();
	}
	
	//Retrieving the particular record
	public Student getParticularRecord(Integer id)
	{
		return repo.findById(id).get();
	}
	
	//Deleting the record method
	public void delete(Integer id)
	{
		repo.deleteById(id);
	}
	
	//Update the record
	public void update(Student updatedStudent) {
	    if(repo.existsById(updatedStudent.getSid())) {	        
	        Student existingStudent = repo.findById(updatedStudent.getSid()).get();
	        existingStudent.setSname(updatedStudent.getSname());
	        existingStudent.setCourse(updatedStudent.getCourse());

	        existingStudent.setDob(updatedStudent.getDob());
	        repo.save(existingStudent);
	    } else {
	        
	        System.out.println("Student with ID " + updatedStudent.getSid() + " not found. Cannot update.");
	    }
	}

	
	
	
}