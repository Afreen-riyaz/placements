package com.bms.placement.student;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.persistence.NoResultException;

@RestController
public class StudentController {

	@Autowired  // Multiple objects can be created by java beans
	private StudentService service;
	
	@GetMapping("/studentservice")
	public List<Student> list()
	{
		return service.listAllRecords();
	}
	
	@PostMapping("/studentservice")
	public void add(@RequestBody Student st)
	{
		service.insertRecord(st);
	}
	
	@GetMapping("/studentservice/{id}")
	public ResponseEntity<Student> get(@PathVariable Integer id)
	{
		try
		{
			Student cust=service.getParticularRecord(id);
			return new ResponseEntity<Student>(cust,HttpStatus.OK);
		}
		catch(NoResultException e)
		{
			return new ResponseEntity<Student>(HttpStatus.NOT_FOUND);
		}
	}
	
	@DeleteMapping("/studentservice/{id}")
	public void delete(@PathVariable Integer id)
	{
		service.delete(id);
	}
	
	 @PutMapping("/studentservice/{id}")
	 public ResponseEntity<Void> updateStudent(@PathVariable Integer id, @RequestBody Student updatedStudent) 
	 {   
		 updatedStudent.setSid(id);
	     service.update(updatedStudent);
	     return new ResponseEntity<Void>(HttpStatus.OK);
	  }
	
	
}
